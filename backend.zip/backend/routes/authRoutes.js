const express = require("express");
const router = express.Router();

console.log("Auth Routes File Loaded");

router.get("/test", (req, res) => {
    res.send("TEST ROUTE WORKING");
});

router.post("/login", (req, res) => {
    console.log("LOGIN ROUTE HIT");
    res.json({
        success: true,
        message: "Login route is working"
    });
});

router.post("/register", (req, res) => {
    console.log("REGISTER ROUTE HIT");
    res.json({
        success: true,
        message: "Register route is working"
    });
});

module.exports = router;